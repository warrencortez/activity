﻿using System;
using MySql.Data.MySqlClient;

namespace OOP
{
    public class DatabaseHelper
    {
        private readonly string connString;

        public DatabaseHelper()
        {
            string server = "localhost";
            string database = "yawa";
            string username = "root";
            string password = "";
            connString = $"Server={server};Database={database};User ID={username};Password={password};";
        }

        public MySqlConnection GetConnection()
        {
            return new MySqlConnection(connString);
        }
    }

    public class AdminLogin
    {
        private readonly DatabaseHelper dbHelper;

        public AdminLogin()
        {
            dbHelper = new DatabaseHelper();
        }

        public bool AuthenticateAdmin(string inputUsername, string inputPassword)
        {
            using (MySqlConnection conn = dbHelper.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Admins WHERE Username = @username AND Password = @password";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@username", inputUsername);
                        cmd.Parameters.AddWithValue("@password", inputPassword);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            return reader.HasRows;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }
        }
    }

    public class ProductManager
    {
        private readonly DatabaseHelper dbHelper;

        public ProductManager()
        {
            dbHelper = new DatabaseHelper();
        }

        public bool InsertProduct(string productName, int productPrice, string productDescription)
        {
            using (MySqlConnection conn = dbHelper.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO products (productName, productPrice, productDescription) VALUES (@name, @price, @description)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", productName);
                        cmd.Parameters.AddWithValue("@price", productPrice);
                        cmd.Parameters.AddWithValue("@description", productDescription);

                        return cmd.ExecuteNonQuery() > 0;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }
        }
    }
}
