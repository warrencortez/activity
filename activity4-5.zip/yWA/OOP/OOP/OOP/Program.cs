﻿using System;
using System.Threading; 
using OOP;

class MainProgram
{
    static void Main()
    {
       
        Console.Clear();
        Console.WriteLine("\n\n\n                                       Please wait, loading system...");
        Thread.Sleep(1500);
        Console.Clear();

        Console.WriteLine(@"                                                                _     _             _       
                                                               | |   | |           (_)      
                                 __ _  ___ ___ ___  _   _ _ __ | |_  | | ___   __ _ _ _ __  
                                / _` |/ __/ __/ _ \| | | | '_ \| __| | |/ _ \ / _` | | '_ \ 
                               | (_| | (_| (_| (_) | |_| | | | | |_  | | (_) | (_| | | | | |
                                \__,_|\___\___\___/ \__,_|_| |_|\__| |_|\___/ \__, |_|_| |_|        
                                                                             __/ |        
                                                                            |___/          
                              ==================================================================
                                                          ACCOUNT LOGIN 
                              ==================================================================
        ");

        Console.Write("                              Enter Admin Username: ");
        string username = Console.ReadLine();

        Console.Write("                              Enter Admin Password: ");
        string password = "";
        ConsoleKeyInfo key;

        do
        {
            key = Console.ReadKey(true);

            if (key.Key != ConsoleKey.Enter && key.Key != ConsoleKey.Backspace)
            {
                password += key.KeyChar;
                Console.Write("*");
            }
            else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
            {
                password = password[..^1];
                Console.Write("\b \b");
            }
        } while (key.Key != ConsoleKey.Enter);

        Console.WriteLine();

        AdminLogin login = new AdminLogin();
        bool isAdmin = login.AuthenticateAdmin(username, password);

        if (isAdmin)
        {
            Console.Clear();
            Console.WriteLine("\n\n\n                                         Logging in...");
            Thread.Sleep(1500);
            Console.Clear();
            Console.WriteLine(@"
                                      ==========================================
                                               ACCOUNT LOGIN SUCCESSFUL!
                                      ==========================================
           ");

            Console.WriteLine(@"                                                   | |                         
                                      __      _____| | ___ ___  _ __ ___   ___ 
                                      \ \ /\ / / _ | |/ __/ _ \| '_ ` _ \ / _ \
                                       \ V  V |  __| | (_| (_) | | | | | |  __/
                                        \_/\_/ \___|_|\___\___/|_| |_| |_|\___|
                                         

   Press any key to Continue...                                                                                                                       ");
            Console.ReadKey();

            Console.Clear();
            Console.WriteLine(@"
                                      ==========================================
                                              ADD  PRODUCTS TO INVENTORY 
                                      ==========================================
            ");

            OOP.ManageProduct.InsertNewProduct newProduct = new OOP.ManageProduct.InsertNewProduct();

            while (true)
            {
                for (int i = 0; i < 3; i++)
                {
                    Console.WriteLine($"\nEnter details for Product {i + 1}:");

                    Console.Write("Enter Product Name: ");
                    string productName = Console.ReadLine();

                    Console.Write("Enter Product Price: ");
                    int productPrice;
                    while (!int.TryParse(Console.ReadLine(), out productPrice))
                    {
                        Console.WriteLine("Invalid input. Enter a valid price.");
                        Console.Write("Enter Product Price: ");
                    }

                    Console.Write("Enter Product Description: ");
                    string productDescription = Console.ReadLine();

                    bool inserted = newProduct.InsertData(productName, productPrice, productDescription);
                    Console.WriteLine(inserted ? "Product added successfully!\n" : "Failed to add product.\n");
                }

                Console.Clear();
                Console.WriteLine(@"                             ===================================================
                                  PRODUCTS HAVE BEEN INSERTED SUCCESSFULLY! 
                             ===================================================");

                Console.WriteLine("                             Do you want to add another set of products? (yes/no):");
                string choice = Console.ReadLine().Trim().ToLower();
                if (choice != "yes")
                {
                    Console.WriteLine("                                           Logging out...");
                    break;
                }
            }
        }
        else
        {
            Console.WriteLine("\nAccess Denied! Invalid Admin Credentials.");
        }
    }
}
